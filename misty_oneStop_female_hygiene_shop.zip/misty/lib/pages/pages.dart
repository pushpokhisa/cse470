import 'package:flutter_ecommerce_website_demo/pages/products/view/products_page_view.dart';

import 'add_product/view/add_product_page_view.dart';
import 'cart/cart_page_view.dart';
import 'contact_us/contact_us_page_view.dart';
import 'home/home_page_view.dart';
import 'orders/orders_page_view.dart';
//import 'phones/view/products_page_view.dart';
import 'sign_in/view/sign_in_page_view.dart';
import 'sign_up/view/sign_up_page_view.dart';

final pageRoutes = {
  '/': const HomePageView(),
  '/products': const ProductsPageView(),
  '/signup': const SignUpPageView(),
  '/signin': const SignInPageView(),
  '/contactus': const ContactUsPageView(),
  '/addproduct': const AddProductPageView(),
  '/cart': const CartPageView(),
  '/orders': const OrdersPageView(),
};
