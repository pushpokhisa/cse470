import 'package:flutter/material.dart';
import 'package:flutter_ecommerce_website_demo/models/product/product_model.dart';
import 'package:flutter_ecommerce_website_demo/providers/page_key_provider.dart';
import 'package:provider/provider.dart';
import '../../../services/firestore_service.dart';
import 'package:stacked/stacked.dart';

import '../../../locator.dart';
import '../../../widgets/text_input/validators.dart';

class AddProductPageViewModel extends BaseViewModel with Validators {
  Future addProduct({
    required BuildContext context,
    required String model,
    required String imageUrl,
    required String price,
    required String stock,
  }) async {
    if (validateModel(model) != null ||
        validateImageUrl(imageUrl) != null ||
        validatePrice(price) != null ||
        validateStock(stock) != null) {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Invalid details'),
          content: Text(
            '${validateModel(model) ?? validateImageUrl(imageUrl) ?? validatePrice(price) ?? validateStock(stock)}',
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('OK'),
              onPressed: () => Navigator.of(context).pop(),
            ),
          ],
        ),
      );
    } else {
      setBusy(true);
      ProductModel productModel = ProductModel(
        model: model,
        price: double.parse(price),
        stock: int.parse(stock),
        imageUrl: imageUrl,
      );
      await locator<FirestoreService>().createProduct(productModel);
      setBusy(false);
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('Success'),
            content: const Text('Product added successfully'),
            actions: <Widget>[
              TextButton(
                child: const Text('OK'),
                onPressed: () {
                  Navigator.of(context).pop();
                  Provider.of<PageKeyProvider>(context, listen: false).key =
                      '/products';
                },
              ),
            ],
          );
        },
      );
    }
  }
}
