import 'package:flutter/material.dart';
import 'package:flutter_ecommerce_website_demo/pages/add_product/view_model/add_product_page_view_model.dart';
import 'package:flutter_ecommerce_website_demo/services/form_service.dart';
import 'package:flutter_ecommerce_website_demo/widgets/busy_button.dart';
import 'package:flutter_ecommerce_website_demo/widgets/text_input/orange_text_form_field.dart';
import 'package:responsive_builder/responsive_builder.dart';
import 'package:stacked/stacked.dart';

import '../../../locator.dart';

class AddProductPageView extends StatelessWidget {
  const AddProductPageView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<AddProductPageViewModel>.reactive(
      viewModelBuilder: () => AddProductPageViewModel(),
      builder: (
        BuildContext context,
        AddProductPageViewModel model,
        Widget? child,
      ) {
        final modelController = TextEditingController();
        final imageUrlController = TextEditingController();
        final priceController = TextEditingController();
        final stockController = TextEditingController();

        final modelInputfield = OrangeTextFormField(
          controller: modelController,
          labelText: 'Model',
          validator: model.validateModel,
          keyboardType: TextInputType.text,
        );
        final imageUrlInputfield = OrangeTextFormField(
          controller: imageUrlController,
          labelText: 'Image Url',
          validator: model.validateImageUrl,
          keyboardType: TextInputType.url,
        );
        final priceInputfield = OrangeTextFormField(
          controller: priceController,
          labelText: 'Price',
          validator: model.validatePrice,
          keyboardType: TextInputType.number,
        );
        final stockInputfield = OrangeTextFormField(
          controller: stockController,
          labelText: 'Stock',
          validator: model.validateStock,
          keyboardType: TextInputType.number,
        );

        final addProductformFields = [
          modelInputfield,
          imageUrlInputfield,
          priceInputfield,
          stockInputfield,
        ];

        return ResponsiveBuilder(builder: (context, sizingInformation) {
          return SingleChildScrollView(
            child: Align(
              alignment: Alignment.topCenter,
              child: AnimatedContainer(
                constraints: sizingInformation.isDesktop
                    ? const BoxConstraints(maxWidth: 1200)
                    : BoxConstraints(
                        maxWidth: sizingInformation.screenSize.width,
                      ),
                duration: const Duration(milliseconds: 60),
                padding: sizingInformation.isDesktop
                    ? const EdgeInsets.symmetric(horizontal: 90)
                    : const EdgeInsets.symmetric(horizontal: 30),
                child: Form(
                  key: locator<FormService>().addProductFormKey(),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Add Product',
                        style: Theme.of(context).textTheme.headline2,
                        softWrap: true,
                        overflow: TextOverflow.visible,
                      ),
                      if (!sizingInformation.isMobile)
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: addProductformFields.sublist(0, 6).map(
                                  (item) {
                                    return Padding(
                                      padding: const EdgeInsets.symmetric(
                                        vertical: 9,
                                      ),
                                      child: item,
                                    );
                                  },
                                ).toList(),
                              ),
                            ),
                            const SizedBox(width: 18),
                            Expanded(
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: addProductformFields.sublist(6).map(
                                  (item) {
                                    return Padding(
                                      padding: const EdgeInsets.symmetric(
                                        vertical: 9,
                                      ),
                                      child: item,
                                    );
                                  },
                                ).toList(),
                              ),
                            ),
                          ],
                        )
                      else
                        ...addProductformFields,
                      BusyButton(
                        title: 'Add Product',
                        busy: model.isBusy,
                        onPressed: () {
                          model.addProduct(
                            context: context,
                            model: modelController.text,
                            imageUrl: imageUrlController.text,
                            price: priceController.text,
                            stock: stockController.text,
                          );
                        },
                      ),
                    ].map(
                      (item) {
                        return Padding(
                          padding: const EdgeInsets.symmetric(vertical: 9),
                          child: item,
                        );
                      },
                    ).toList(),
                  ),
                ),
              ),
            ),
          );
        });
      },
    );
  }
}
