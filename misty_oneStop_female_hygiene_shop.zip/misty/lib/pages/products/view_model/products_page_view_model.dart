import 'package:flutter_ecommerce_website_demo/models/product/product_model.dart';
import 'package:stacked/stacked.dart';

class ProductsPageViewModel extends BaseViewModel {
  List<ProductModel> _productModels = [];

  List<ProductModel> get productModels => _productModels;

  void setProductModels(List<ProductModel> productModels) {
    _productModels = productModels;
  }
}
