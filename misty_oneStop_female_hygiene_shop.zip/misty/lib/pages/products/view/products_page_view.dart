import 'package:flutter/material.dart';
import 'package:flutter_ecommerce_website_demo/models/product/product_model.dart';
import 'package:flutter_ecommerce_website_demo/pages/products/view/widgets/product_specifications_card.dart';
import 'package:flutter_ecommerce_website_demo/pages/products/view_model/products_page_view_model.dart';
import 'package:flutter_ecommerce_website_demo/services/firestore_service.dart';
import 'package:responsive_builder/responsive_builder.dart';
import 'package:stacked/stacked.dart';

import '../../../locator.dart';

class ProductsPageView extends StatelessWidget {
  const ProductsPageView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<ProductModel>>(
        stream: locator<FirestoreService>().readProducts,
        builder: (
          BuildContext context,
          AsyncSnapshot<List<ProductModel>> snapshot,
        ) {
          return ViewModelBuilder<ProductsPageViewModel>.reactive(
            viewModelBuilder: () => ProductsPageViewModel(),
            builder: (
              BuildContext context,
                ProductsPageViewModel model,
              Widget? child,
            ) {
              List<Widget> productCards = [];
              int middle = productCards.length ~/ 2;
              if (snapshot.hasData) {
                if (snapshot.data != null) {
                  model.setProductModels(snapshot.data!);
                  model.setProductModels(snapshot.data!);
                  productCards = List.generate(
                    model.productModels.length,
                    (index) => ProductSpecificationsCard(
                      product: model.productModels[index],
                    ),
                  );
                  middle = productCards.length ~/ 2;
                } else {
                  productCards = [
                    Center(
                      child: Text(
                        'No Products',
                        style: Theme.of(context).textTheme.headline6,
                      ),
                    ),
                  ];
                }
              } else if (snapshot.hasError) {
                productCards = [
                  const Center(
                    child: Icon(
                      Icons.error_outline_rounded,
                      color: Colors.red,
                    ),
                  )
                ];
              } else {
                productCards = [
                  const Center(
                    child: CircularProgressIndicator(),
                  ),
                ];
              }
              return ResponsiveBuilder(
                builder: (
                  BuildContext context,
                  SizingInformation sizingInformation,
                ) {
                  return SingleChildScrollView(
                    child: Align(
                      alignment: Alignment.topCenter,
                      child: AnimatedContainer(
                        constraints: sizingInformation.isDesktop
                            ? const BoxConstraints(maxWidth: 1200)
                            : BoxConstraints(
                                maxWidth: sizingInformation.screenSize.width,
                              ),
                        duration: const Duration(milliseconds: 60),
                        padding: sizingInformation.isDesktop
                            ? const EdgeInsets.symmetric(horizontal: 90)
                            : const EdgeInsets.symmetric(horizontal: 30),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Browse Products',
                              style: Theme.of(context).textTheme.headline2,
                              softWrap: true,
                              overflow: TextOverflow.visible,
                            ),
                            if (!(sizingInformation.isMobile))
                              Row(
                                mainAxisSize: MainAxisSize.min,
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children:
                                          productCards.sublist(0, middle).map(
                                        (item) {
                                          return Padding(
                                            padding: const EdgeInsets.symmetric(
                                              vertical: 9,
                                            ),
                                            child: item,
                                          );
                                        },
                                      ).toList(),
                                    ),
                                  ),
                                  const SizedBox(width: 18),
                                  Expanded(
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children:
                                          productCards.sublist(middle).map(
                                        (item) {
                                          return Padding(
                                            padding: const EdgeInsets.symmetric(
                                              vertical: 9,
                                            ),
                                            child: item,
                                          );
                                        },
                                      ).toList(),
                                    ),
                                  ),
                                ],
                              )
                            else
                              ...productCards,
                          ].map(
                            (item) {
                              return Padding(
                                padding:
                                    const EdgeInsets.symmetric(vertical: 9),
                                child: item,
                              );
                            },
                          ).toList(),
                        ),
                      ),
                    ),
                  );
                },
              );
            },
          );
        });
  }
}
