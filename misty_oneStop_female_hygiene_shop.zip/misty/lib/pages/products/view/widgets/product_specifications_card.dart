import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

import '../../../../services/authentication_service.dart';
import '../../../../widgets/busy_button.dart';
import '../../../../locator.dart';
import '../../../../models/product/product_model.dart';
import 'specification_field.dart';

class ProductSpecificationsCard extends StatefulWidget {
  const ProductSpecificationsCard({
    Key? key,
    required this.product,
  }) : super(key: key);

  final ProductModel product;

  @override
  State<ProductSpecificationsCard> createState() =>
      _ProductSpecificationsCardState();
}

class _ProductSpecificationsCardState extends State<ProductSpecificationsCard> {
  bool _isHovered = false;
  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) => setState(() => _isHovered = true),
      onExit: (_) => setState(() => _isHovered = false),
      child: Card(
        elevation: _isHovered ? 12 : 0,
        shadowColor: _isHovered ? Colors.orange : Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(21),
          side: BorderSide(
            color: _isHovered ? Colors.orangeAccent : Colors.grey,
            width: 3,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 21, horizontal: 42),
          child: Column(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: Center(
                  child: CachedNetworkImage(
                    imageUrl: widget.product.imageUrl,
                    errorWidget: (context, url, error) => Icon(
                      Icons.error,
                      color: Colors.red.shade700,
                    ),
                    progressIndicatorBuilder: (context, url, downloadProgress) {
                      return CircularProgressIndicator(
                        value: downloadProgress.progress,
                      );
                    },
                    fit: BoxFit.contain,
                  ),
                ),
              ),
              // model
              SpecificationField(
                fieldName: 'Model',
                fieldValue: widget.product.model,
              ),
              SpecificationField(
                fieldName: 'Price',
                fieldValue: '€${widget.product.price}',
              ),
              // quantity
              SpecificationField(
                fieldName: 'Stock',
                fieldValue: '${widget.product.stock}',
              ),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: BuyProductBusyButton(product: widget.product),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class BuyProductBusyButton extends StatelessWidget {
  const BuyProductBusyButton({
    Key? key,
    required this.product,
  }) : super(key: key);

  final ProductModel product;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: BusyButton(
        title: 'Buy',
        onPressed: () {
          if (product.stock > 0) {
            if (locator<AuthenticationService>().currentUser != null) {
              showDialog(
                context: context,
                builder: (BuildContext context) {
                  return AlertDialog(
                    title: Text('${product.model} added to cart'),
                    content: const Text('This feature is coming soon'),
                    actions: [
                      TextButton(
                        child: const Text('OK'),
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                      ),
                    ],
                  );
                },
              );
            } else {
              showDialog(
                context: context,
                builder: (BuildContext context) {
                  return AlertDialog(
                    title: const Text('You need to be logged in'),
                    content: const Text('This feature is coming soon'),
                    actions: [
                      TextButton(
                        child: const Text('OK'),
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                      ),
                    ],
                  );
                },
              );
            }
          } else {
            showDialog(
              context: context,
              builder: (BuildContext context) {
                return AlertDialog(
                  title: Text('${product.model} is out of stock'),
                  content: const Text('This feature is coming soon'),
                  actions: [
                    TextButton(
                      child: const Text('OK'),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                    ),
                  ],
                );
              },
            );
          }
        },
      ),
    );
  }
}
