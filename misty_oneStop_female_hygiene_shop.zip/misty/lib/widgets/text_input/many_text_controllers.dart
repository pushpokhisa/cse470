import 'package:flutter/material.dart';

final modelController = TextEditingController();
final imageUrlController = TextEditingController();
final socController = TextEditingController();
final ramController = TextEditingController();
final storageController = TextEditingController();
final screenSizeController = TextEditingController();
final batteryController = TextEditingController();
final cameraController = TextEditingController();
final priceController = TextEditingController();
final stockController = TextEditingController();
final sarController = TextEditingController();
