import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

part 'product_model.freezed.dart';
part 'product_model.g.dart';

@Freezed()
abstract class ProductModel implements _$ProductModel {
  const ProductModel._();

  const factory ProductModel({
    required String model,
    required String imageUrl,
    required double price,
    required int stock,
  }) = _ProductModel;

  factory ProductModel.fromJson(Map<String, dynamic> json) =>
      _$ProductModelFromJson(json);

  factory ProductModel.fromDocument(DocumentSnapshot document) {
    return ProductModel.fromJson(document.data()! as Map<String, dynamic>);
  }

  Map<String, dynamic> toDocument() => toJson();
}
